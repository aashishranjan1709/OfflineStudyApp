# Study Desk — Offline Android study app (prototype)

A lightweight Android app shell with a bundled offline study interface. Intended for UPSC CSE study on phones and tablets, including stylus use on Android tablets.

## Features in this prototype
- Offline dashboard, subject categories, sample quiz and revision checklist
- Typed notes with create/edit/delete and local storage
- PDF library: import PDFs from Android's document picker, store them in the app's private files, list/delete them, and open them using an installed PDF reader
- Notes Studio: stylus/finger handwriting canvas, pen/highlighter/eraser, ink color and size, undo, ruled paper, typed companion notes, saved image pages
- Export/import JSON backup for app data
- No INTERNET permission; study UI and core data are local

## Build the APK
This workspace does not have Android SDK/Gradle build tools installed, so an APK could not be compiled or device-tested here.

1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this `OfflineStudyApp` folder in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin, Kotlin plugin, and AndroidX Core dependency.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android device and allow installation from your chosen file manager if prompted.

## Important limitations
- This is a prototype, not a full Samsung Notes replacement. It provides basic handwriting and local note pages, but does not yet provide Samsung Notes-level palm rejection, pressure/tilt tuning, handwriting recognition, PDF markup/split view, audio recording, sync, or multi-page notebook management.
- The app opens imported PDFs in an installed Android PDF reader. It does not yet render PDFs inline or write annotations directly into PDF files.
- Stylus input depends on the device/WebView delivering pointer events; hardware-level palm rejection is not guaranteed by this prototype.
- Sample quiz questions and revision topics are starter content, not a complete or official UPSC question bank.
- Notes use local app storage. Export backups before clearing app data or uninstalling.
- Source syntax was checked, but the app has not been compiled or tested on a physical device in this environment.
