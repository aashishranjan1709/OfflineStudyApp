package com.example.offlinestudy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val pdfDir: File by lazy { File(filesDir, "pdf-library").apply { mkdirs() } }
    private val pickPdfRequest = 4317

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(StudyBridge(), "StudyBridge")
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private inner class StudyBridge {
        @JavascriptInterface fun pickPdf() { runOnUiThread {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(intent, pickPdfRequest)
        } }

        @JavascriptInterface fun listPdfs(): String {
            val result = JSONArray()
            pdfDir.listFiles()?.filter { it.isFile && it.extension.equals("pdf", true) }
                ?.sortedBy { it.name.lowercase() }?.forEach { file ->
                    result.put(JSONObject().put("name", file.name).put("size", file.length()))
                }
            return result.toString()
        }

        @JavascriptInterface fun openPdf(name: String) { runOnUiThread {
            val file = safePdf(name) ?: return@runOnUiThread
            try {
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this@MainActivity, "Install a PDF reader to open this file.", Toast.LENGTH_LONG).show()
            }
        } }

        @JavascriptInterface fun deletePdf(name: String) { runOnUiThread {
            val file = safePdf(name)
            if (file != null && file.delete()) {
                webView.evaluateJavascript("refreshPdfs()", null)
                Toast.makeText(this@MainActivity, "PDF deleted", Toast.LENGTH_SHORT).show()
            }
        } }
    }

    private fun safePdf(name: String): File? {
        val clean = File(name).name
        if (!clean.lowercase().endsWith(".pdf")) return null
        val f = File(pdfDir, clean).canonicalFile
        return if (f.parentFile == pdfDir.canonicalFile && f.isFile) f else null
    }

    @Deprecated("Use Activity Result APIs in a future update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickPdfRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val original = queryDisplayName(uri) ?: "study-material.pdf"
            var base = File(original).name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            if (!base.lowercase().endsWith(".pdf")) base += ".pdf"
            var target = File(pdfDir, base)
            var index = 2
            while (target.exists()) {
                val stem = base.removeSuffix(".pdf")
                target = File(pdfDir, "$stem ($index).pdf")
                index++
            }
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
                ?: throw IllegalStateException("Could not read selected PDF")
            val jsName = JSONObject.quote(target.name)
            webView.evaluateJavascript("onPdfImported($jsName)", null)
        } catch (_: Exception) {
            Toast.makeText(this, "Could not import this PDF. Try another file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Back navigation support")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
